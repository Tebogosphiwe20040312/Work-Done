<!DOCTYPE html>
<html lang="en">

<head>
    <title>Jane.Corp/Sign-Up/Confirmation</title>
    <link rel="stylesheet" href="Sign Up Confirmation style.css">
</head>

<body>
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Jane.Corp</h2>
            </div>
        </div>
        <div class="content">
            <form method="POST" class="form">
                <p class="pr"> You have successfully signed up! </p>
                <a href="Jane.Corp.html" class="return">Go to Login</a>
            </form>
        </div>

        <?php
        
        ?>
    </div>
</body>

</html>